# Lion Secured Android (High-Security) - Option C

This bundle contains an Android Studio project skeleton with strong security modules. See docs/ for setup.